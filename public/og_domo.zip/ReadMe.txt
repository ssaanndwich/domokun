CS559 Nathalie Cheng
I worked alone on this assignment.

This program creates a single window and draws a very simple face of Domo (a.k.a. Domo-kun), the official mascot of Japan's NHK television station, using geometric primitives such as lines, rectangles, polygons, and triangles and fills them with different colors. (Please refer to the screenshot).

There are 3 code files - 
MyOpenGLWindow.cpp
MyOpenGLWindow.h
main.cpp