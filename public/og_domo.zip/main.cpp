#include "MyOpenGLWindow.h"

int main(int argc, char** args)
{
	MyOpenGLWindow myWindow;
	myWindow.show();

	Fl::run();

	return 0;
}
