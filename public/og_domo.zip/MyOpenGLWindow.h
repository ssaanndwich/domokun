#ifndef MY_OPENGL_WINDOW_H
#define MY_OPENGL_WINDOW_H

#include <windows.h>

// Disable the warning between the block of push and pop
#pragma warning (push)           
// The list of numbers of warning we will like to disable 
#pragma warning(disable : 4204)
#pragma warning(disable : 4244)
#pragma warning(disable : 4312)
#pragma warning(disable : 4311)
#pragma warning(disable : 4083)
#pragma warning(disable : 4193)
// List of all fltk include files 
#include <Fl/Fl.h>
#include <Fl/Fl_Gl_Window.h>
#pragma warning (pop) // Enable the warning again

class MyOpenGLWindow : public Fl_Gl_Window {
public:
	MyOpenGLWindow();
	virtual void draw();
	virtual ~MyOpenGLWindow();
};

#endif
