#include "MyOpenGLWindow.h"
#include <Gl/gl.h>
#include <Gl/glu.h>

MyOpenGLWindow::MyOpenGLWindow() : Fl_Gl_Window(100,100,600,600,"My OpenGL program") {
	mode(FL_RGB | FL_ALPHA | FL_DEPTH | FL_DOUBLE);
}

MyOpenGLWindow::~MyOpenGLWindow()
{}

void MyOpenGLWindow::draw() {
	// clears the background of the drawing area	
	glClearColor(0,0,0,0);
	glClear(GL_COLOR_BUFFER_BIT);

	// technically we should set up the drawing transform here
	// but for now, we'll assume its the identity, and will stay
	// that way since this is the only drawing code in the program

	// draws a red line
	glColor3f(1,0,0);
	glBegin(GL_LINES);
	glVertex3f(-0.5, 1, 0);
	glVertex3f(-0.5, -1, 0);
	glEnd();

	// draws a blue triangle
	glColor3f(0,0,1);
	glBegin(GL_TRIANGLES);
	glVertex3f(1, 1, 0);
	glVertex3f(-1, 0, 0);
	glVertex3f(1, -1, 0);
	glEnd();

}
