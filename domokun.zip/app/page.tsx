"use client"

import Domokun from "../domokun"

export default function Page() {
  return (
    <div>
      <Domokun />
    </div>
  )
}
